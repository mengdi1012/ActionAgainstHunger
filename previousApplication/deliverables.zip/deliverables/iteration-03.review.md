ActionAgainstHunger


## Iteration XX - Review & Retrospect

 * When: Nov 29th
 * Where: Online


#### Decisions that turned out well

We decide to separate front-end and back-end work to different group members. It turns out to be successful since testing database connection will not be affected by front-end changes. 

We decide to do some investigation on which amazon service will be most suitable for us, which is a good decision since when we get stuck on setting up some services like mobile hub, we can try different options like amplify.
We make changes according to our clients’ requests, and include it in our sprint planning. It is important to make response to our clients’ requests, which is also an advantage in scrum workflow.


#### Decisions that did not turn out as well as we hoped

We hope to start setting up amazon web service early in the sprint. Unfortunately, there’s an issue with our account, which were solved in the second week of our sprint. It affects significantly with our database connection testing.

Investigating many options of amazon services is time-consuming. We first try with mobile hub service and follow the guiding doc. However, we meet some invalid identity pool configuration error which turns out to be related to different roles division policy in amazon service. Then we try other options like Amazon Amplify, which also costs us a lot of time.

We hope to integrate the database with the frontend and could have given more time to finish this. However whenever trying new methods people inevitably run into errors, this is learning. We probably should have given the team more time to resolve issues that would come up. 

#### Planned changes

Since our access to the amazon web service came in late in this sprint, and we are not familiar with setting up database connections, we realized the possibility that we may not actually be able to build the read/write feature for different types of data. Then we changed the plan to contribute as much as we could to build up the foundation of connection.

We spent a long time figuring out the Amazon web services initialization, and till the end of the sprint, we finished our user registering. We will keep investigating read/write other type of data like posts, feeds and news in the future sprint.
From the authentication part, since we are using Amazon’s amplify service, the UI part and functionality will differ from what we had before. We need to make some changes in the registering fields in the later sprint.


## Product - Review

#### Goals and/or tasks that were met/completed:

We were able to change a lot of the frontend parts to be better, which is a nice success considering a lot of us were not too familiar with Android Studio before the project began. Now, most of us can make sizeable changes to the app depending on their own specifications.

We are able to authenticate users by the Amazon amplify service, so that now client can register an account by receiving confirmation code from their emails, and reset the password in a similar way. All user account can be saved and manages on Amazon cognito user pool. It is a huge progress on our team since we are not familiar with Amazon integration before, and we are able to solve many issues together when investigating Amazon documents.

Finally, I think we did a good job on the entire learning curve. We were able to communicate with our client, talk out details, and split up work featuring AWS and App development. In other words, this was a good experience for feeling what a real project would be like in a job down the line.


#### Goals and/or tasks that were planned but not met/completed:


The most significant goal we basically didn’t meet was the issues regarding the database and AWS DynamoDB. We didn’t have enough time to investigate DynamoDB connection in this sprint, since authentication activity alone took us more time than we have planned.

The core of the problem was a factor of multiple things. Firstly, it was unfortunate that none of us had any real experience with using Amazon Web Services. So, while most of us were fine with creating database objects and how to use them, we were completely roadblocked by a plethora of authorization, remote access, and java integration issues. Combined with the fact that our AWS account was only opened the Monday of the final week (leaving us ~4 days to setup the database), and that the documentation was scarce for our particular issues, it was a pity we couldn’t get everything planned done on time, but a good learning experience for web service integration.

A lot of our issues were mostly roadblocked by our issue above, so we can categorize most of them into the above sentiments. For example, things like access levels are directly tied to the authorization web service, which we kept switching around.


## Meeting Highlights

We need to start development timelines with the expectation of errors with the usage of new tools such as AWS and and frameworks such as DynamoDB, Amplify and Cognito. Embarking on projects involving new technologies will inherently lead to complications, if not then it's not new to us. We should factor this into our timelines.

We found out that the skill sets needed to develop in MySQL and DynamoDB are completely different and therefore we should stick with one platform even though that platform has certain drawbacks. This means that choosing the tools to use would require a lengthy pros and cons table that would weigh out the potential benefits and drawbacks of a certain technology. This is what we did early on when we decided to use AWS for the multiple frameworks it ran.

