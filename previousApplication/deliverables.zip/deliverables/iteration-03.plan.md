# ActionAgainstHunger


## Iteration 3

 * Start date: Nov 19th
 * End date: Nov 30th


#### Changes from previous iteration

We will set up cloud database on amazon database server and try to see which service suits us best(like Amazon cognito, amplify, mobile hub) Since our application serves for an organization, our database connection should be secure with user authentication and a controllable user pool.

We want to make changes according to the feedback from our clients, which includes some UI changes, content reorganization and new features. From these changes, we hope it will have a better performance in the real cases.


#### Roles & responsibilities

Role division:

Back-end:
Yifang: Make changes to accomodate feature updates about login and register, set up database connection for user management
Chaitanya: Set up database connections for sending/retrieving posts and comments
Raymond: Automatic username/password generation, aiding in database connection for sending general data.

Front-end:
Neil: Working on retrieving posts and comments
Brandon: Implement different post categories and investigate methods for retrieving images/other media for posts
Tommy: Implement filter to newsPosts.
Ahmad: remove profile images and add icons, mainpage feed features.

#### Events

We will regularly conduct meetings in person during tutorial hours and in the our online chat room to discuss further steps and report on progress. Mainly, we will use the meetings to coordinate the way in which we are setting up the database, and any relevant connections within the application. This is important in order to make our data structures efficient and clean. 

#### Artifacts

For the product, we wanted to create some videos that showcased aspects of our app. Particularly, a front-end component like the video from Phase 1, but also a backend showing what happens remotely on the AWS servers.

We are going to investigate authentication and DynamoDB from Amazon web service and try to see our item created in our app will reflect on the cloud database. The DynamoDB feature should be implemented after the authentication setup.


#### Git / GitHub workflow

Each team member has their own forked copy of the project repository. If someone wants to add code they usually first pull the changes from the project repository, add and commit their changes to their own repository, and then submit a pull request from their own repository to the project repository. They then notify the group to check their code, if any issues are found they are asked to revise their pull request and notify us again when they fixed it, otherwise it is merged into the project repository.

We choose this workflow since it allows to maintain clean code and have multiple team members familiar with the same parts of code so that if any issues arise we do not have to rely on just one team member to figure the problem out.


## Product

#### Goals and tasks

Our goals for this sprint were primarily to finish the features left of the app, in addition to considering the feedback our client left us after Phase 1:

Main Goals
Set up an AWS account and work out the management of the security/ownership
Create base tables for the Users, Posts, Personal Info on AWS DynamoDB
Allow read/write to the web service

Client Updated Goals
For the main menu, if instead of just a Newsfeed, we could filter them into three categories: News, Questions, and Highlights
Allow only admins or teachers to create accounts (prevents bad names from students and such)
Allow only admins or teachers to change pictures to icons 


#### Artifacts

For the product, we wanted to create some videos that showcased aspects of our app. Particularly, a front-end component like the video from Phase 1, but also a backend showing what happens remotely on the AWS servers.

Due to unexpected issues along the way though, we were also forced to look into many things that may have resolved parts of our problem(s), including:
MongoDB for storing images/videos, since we were expecting audio to be a big component of how our app would function
AWS Amplify when AWS Cognito was far too confusing to set up in short time, although it was still quite tough to use regardless
MySQL when DynamoDB kept throwing issues due to permissions or configurations we didn’t understand
Switching the logo icon multiple times due to client-side company policies

