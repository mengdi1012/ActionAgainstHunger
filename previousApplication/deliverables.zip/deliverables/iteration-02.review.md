# Action Against Hunger

## Iteration 02 - Review & Retrospect

When: November 2nd, 2018

Where: Robart Library

## Process - Reflection

As part of the review meeting we demoed the app on our phones and made sure that we hit all of our targets for the posts. We wanted to make sure that our app was able to login users, have a newsfeed, have a profile status, and create posts and comments. We wanted to ensure that this was as visually appealing as possible. 

#### Decisions that turned out well

 - Working online with a set of priorities already set on google docs:
 
   Instead of working together we realized that everyone has a time and place that they can be the most productive and get the most things done. In order to increase productivity and each individual contribution to the app, we decided to create a google document listing everyone's responsibility early on in the planning phase so that there were clearly defined responsibilities. This also allowed group members to work at home when free and everyone to contribute at their own comfort.
   
 - Using discord as a community group chat that fostered a shared and helpful learning experience:
 
   We realized that we needed a method of communicating with each other in a non formal format so that we could sort out compatibility issues with our individual code to create the final product. Therefore we used discord as a forum to facilitate team communications. This was a success in process planning as we could pin other users we wanted to talk to and could cross collaborate with other team members to make sure our method/class functionality was not overlapping. Every team member also benefited from knowledge of other team members as we ran into individual grievances with the software we were not able to fix.
   
 - Creating a uml diagram before building the app was useful as we could model our classes and subsequently our UI to interface with those classes. This step was beneficial as it solidified the concept that everyone had in their head to a structure that was executable. Therefore, once the structure was planned out, the amount of time we spent actually programming decreased due to reduced overlapping of group members functions/classes. This increased efficiency.

#### Decisions that did not turn out as well as we hoped

 - We did not create a functional timeline for the completion of work in the name of individual flexibility. However due to other academic work this resulted in a delayed start to the project. The teams workflow would have been better and more formulated and efficient if there was not necessarily a strict deadline for every single class but a deadline for the entire team as a whole to produce a minimal viable product. This would provide more time for refinement and refactoring if necessary. 

 - Having more meetings and discussion online instead of in person affected overall team communication. This is as in person meetings often provides an environment that allows people to get more creative and bring more audacious ideas to the table. Having the majority of meetings online made the execution more effective as it allowed for need based communication but detracted from formulation of the larger picture of our application.  

 #### Planned changes

 - We want to set a deadline at least a week before the actual deadline for the creation of the application in order to refine and polish our app in looks and function. This will enable us to create a better product.

 - We will also have video calls whenever needed as it will have the same benefits as in person meetings, namely open and continuous stream of conversation, but also allows us to do so from wherever we are comfortable. 

## Product - Review

#### Goals and/or tasks that were met/completed:

 - We finished all front-end layouts and basic activity transitions between layouts.
 - Made a video to demonstrate the major feature of our application.
 - Role division and workload separation turned out to be successful and satisfying.
 - Created a draft of the icon of our app.
 - Talked to the client about our database account setup. We should be able to build up an AWS connection in the next sprint.



#### Goals and/or tasks that were planned but not met/completed:

 - We hoped to make some progress on the backend database setup, and the organization needs time to discuss about the AWS service funding. Therefore, we didn’t actually test our database connection code in this sprint.

 - We planned to have more in-person meetings to discuss about the progress, yet we were all busy in this sprint. Alternatively, we more often met up online, which was also efficient.

## Meeting Highlights

 - Figure out the database setup and serverless feature of AWS we are going to use.
 - Achieve the major function of our application, like user signing in, and forum interaction.

