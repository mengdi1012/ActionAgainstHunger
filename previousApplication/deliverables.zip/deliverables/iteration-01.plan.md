# ActionAgainstHunger


## Iteration 01


Start date: October 3rd, 2018

End date:  October 14th, 2018

## Process


Our team discussed with the clients about their requests and features of the android app they want to have. They explained to us the idea of the program, what would be fundamental features, and what would be good to have. Our team asked several questions about possible solutions or alternatives for specific requirements. In all, the first meeting is an introductory one, team gets familiar with the project and the clients can have chance to think about features, and make them more concrete.

### Roles & responsibilities

There will not be much difference on team roles in this sprint as we meet our clients together and ask questions from different points of views. Then we will hold online meetings regularly to discuss technical details together. We hope to reach agreements about the features we plan to build for the next sprint. The team will contribute as a whole and hopefully everyone has a chance to review the project.


### Events

After our main meeting with our clients, we are looking into two different types of meet up.

##### Major meetings - Discord

We have a group chat with our clients on Discord. We are planning to hold bi-weekly meetings as necessary, to both inform the clients of our general progress, and get potential clarifications as they arise.

##### Casual meetings - Discord

Our group has a team discord which we can hop on and quickly discuss details if the need arises. There is no set time or date, but the discussions here will like be a few quick questions at most.




### Artifacts 

From our meeting, we formulated a few artifacts we would like to achieve for our first sprint.

 - Create a subscription with the AWS service, and have all group members get a general understanding of how non-relational SQL works.
 - Decide on the core features that are prioritized (such as login, and post and read functionality), and which can be left and looked at if we have time.
 - We will discuss the technical details on our next sprint planning session and assign to team members according to prioritized features and whether the team member is comfortable at the workload and complexity.
 - Setup our git repository, and perhaps think about how many major files and packages we require.

## Product

### Goals and tasks 

As we are working for a non-profit for our project, our main goals are gathered from the meeting with two of our organization leaders. In order to discuss the aims, specific details, and direction that we all could agree on. The process lasted for around 70-80 minutes in total, and we managed to figure out quite a few things we were unsure on - and likewise for the opposing party.

Here are a few of the key goals that we discussed:

 - Who the intended audience of the application will be:
     - Our clients are paired with around 20-30 schools around Canada at the moment.
     - The primary users would be their students and teachers.
     - Guest users, such as health specialists or farmers could also use the app.

 - What the primary functionality of the app should be:
    - A strong focus on posting and reading/commenting on others’ posts.
    - Effectively, students should be able to grow tomatoes or something, post their tomatoes, and receive feedback and applause from their peers.
    - Ask questions and have nutrition experts to provide professional answers.

 - What some boundaries of our development will be:
    - Focus on using a small database system, since the expected scope is small (for now).
    - Archive posts after some time so the system does not get too crowded.
    - Allow different schools to see others’ posts through a public section, and only their own schools’ through a private section.

 
### Artifacts 

In terms of presentation, we also came up with a few artifacts.

 - Creating general overlays (mockups) of how a few key screens of our app would look. The important part would be the specific functionality of the buttons, and how one screen is connected relative to another.

 - Create a general UML to show how our system would be designed and interconnected through the backend.

 - We will present an interactive user case to help people understand the community feature of our app. Users can comment and ask questions freely and receive responses instantly.
