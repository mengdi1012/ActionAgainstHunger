# ActionAgainstHunger

## Iteration 01 - Review & Retrospect 

Date of Meeting: October 12th 2018

Location: Online on discord

## Process - Reflection 

There is not much difference on team roles in this sprint as we met our clients together and asked question from different points of views. Then we had online meeting regularly to discuss technical details together. We have reached agreements about the features we plan to build for the next sprint. The team contributed as a whole and finished the phase 1 together.



#### Decisions that turned out well 

1)	Focus on the communication medium, and let the users create their own content.
This allows the users (students and teachers) to be more engaged with the app, since it is a rather flexible medium in that sense.
We will minimize issues of over-ambition, that is, we can focus on a few core features and not risk doing something ingeniously tough which results in failure down the line.

2)	Use different types of accounts to distinguish users, but allow public viewing.
This resolves an issue of privacy as well as net security, although we do not imagine it would be a huge risk regardless.
Public viewing allows schools to understand what they could do with different things (for instance, a school in the rural areas could do more outdoor growing, and a city school may have better cooking or exercising facilities - and both can see what the other is doing).

3)	Use a free database system and allow guests to use it freely (fairly freely).
The scope of the project is quite small currently, and both our clients and our team agreed that there is little point in investing in a better database service as of now.
Including guests will allow third party professionals to both help engage and increase the coherence of our app.


#### Decisions that did not turn out as well as we hoped

1)	We had decided to try and create a strict distinction between the roles that group members would have. However, as we considered the additional features we could/wanted to add to the project, we decided to be more flexible with the roles that group members would have. This would enable us to be more flexible in our roles while still recording our contributions and being accountable for them. This approach would allow the team to take a more flexible approach towards development while still achieving goals in an iterative manner.

2)  At first we thought about creating revenue streams and focused on the big  picture of the product in order to sustain itself in the long term. However, we later decided to abandon the approach and focus first on creating a minimal viable product after reviewing the wishes of our clients; who only want it for 30 schools (relatively small community). They therefore would not incur any extensive server hosting charges.    

3)	We at first did not know how to organize the team and keep in touch with one another and our clients. At first we had decided to meet whenever multiple teams/people had reach certain individual goals in order to integrate them into a larger service. In retrospect, we decided to hold at least a weekly code review with the entire team and with the clients so that we could measure individual progress, talk about troubles that perhaps may need cross collaboration within the team and promote an environment of open communication between colleagues and with our clients. 




#### Planned changes

- Since we are just starting, we do not have any particular changes projected, however, we do have a few key ways we want to organize our project
- Set smaller goals (initially we looked at the whole picture, for the next sprint we want to narrow down a few core features first)
- Assign roles/groups (for this sprint, we all worked as a big group, but we have to spread out roles, or we risk not finishing sprints with more tasks)


## Product - Review

#### Goals and/or tasks that were met/completed: 

- Successfully met with clients and understood the logistics of our problem/app
- Decided on a web service and general medium we would use (AWS, Android)
- Structured our group to communicate easily with one another (Discord)


#### Goals and/or tasks that were planned but not met/completed:

We more or less completed all the tasks this week. However, since we did not write any code yet, there are still lots of new tasks that will pop up for the next few sprints, so we will need to keep up on those.





## Meeting Highlights

Going into the next iteration, our main insights are:

 - Focus on features like account registeration, sign in, and profile management
 - Decide the order of features to implement, make sure teammates work are not blocking each other
 - Online meeting is as efficient as the in-person one, we will keep regular meeting online

