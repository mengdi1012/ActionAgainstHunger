# Action Against Hunger

## Iteration 02

 Start date: October 15th, 2018
 
 End date: October 28th, 2018

## Process

#### Roles & responsibilities

Roles: We primarily split ourselves based on which area of the product we were working on, and aside from that, some of us will take up certain optional roles that have to do more with logistics and utility duties. The roles are basically divided as such:

Frontend Group: Neil, Tommy

Backend Group: Yifang, Chaitanya, Ahmad, Brandon, Raymond

Misc Roles: Communicator with Non-Profit, Scrum Master, Icon Designer, Meeting Scheduler... 

Responsibilities: We each take up a specific area of the product to work on, and proceed from there to aid in areas that are related/required to finish our respective tasks. The division was something like this (roughly):

Login And Authentication: Yifang
Profile: Ahmad
Posts and Comments: Brandon, Chaitanya, Raymond
FrontEnd (Views): Neil, Tommy

#### Events

Primary:

Discord Meetings: We will do the bulk of our discussions and shot calling at online meetings on our group Discord server. The purpose is usually to ask questions about coding issues we are not sure about, discuss whether something should be done now or later, or simply schedule time to do meetups or work on documents.


Secondary:

Real Life Meetings: We’ve done one of these this sprint, and that is for the purpose of clearly dividing our roles and responsibilities, whilst giving insight into how we might progress the app afterwards. We also go over how we would talk with our non-profit about them signing up for AWS, for ease of transferring. 


#### Artifacts

We use a variety of things, none of which are more ‘mandatory’ than others:
 - Google Docs, where we usually will record logs of what we set out to get done, or store appropriate document texts which we may want to reuse later.
 - Discord Messages, usually these are for temporary goals which get accomplished in short time, since these tend to quickly get drowned out in the chat
 - Personal notes, well, not a lot of these are done, but for particularly important matters, we sometimes keep private notes digitally or physically




#### Git / GitHub workflow

First of all, we contribute to the team branch by submitting pull requests from our individual local branches, and then review the pull requests together. If the majority of us has reviewed and agreed, we will merge the code from local branch to team branch.

One of the team members will create a pull request to the team branch for the skeleton package of our whole project, thus facilitating others to push their codes to the corresponding folders. This fundamental pull request will be examined by everyone to make sure we understand, and have discussions. After that, we will divide our role into different features, which will result in new files in different folders and snippets of codes added to an overall structural file.

If a pull request has conflicts with the team branch, we will talk on discord to review related codes together. If the team branch can be further improved by this pull request, we will resolve the conflicts and merge them. During this review, we will also make sure that the fundamental skeleton code of our application has not been changed, and other important compiling files are not touched as well. 

## Product

#### Goals and tasks

Primary Goals:
 - Create the view hierarchy and allow the user to move through them.
 - Get a basic login page with locally stored credentials.
 - Have a newsfeed for all posts and a view for each post.
 - Have views for comments on each post.
 - Have objects for posts, comments, users, etc.
 - Allow the user to make posts and comments.


#### Artifacts

Here are the main Artifacts we want to produce:
 - Finish the skeleton of the app, so that it can at least be run as a sample for both the video recording as well as a logical model so we can implement more complex features
 - Screen recording to demo app, which would be a simple traversal of the general structure and the features that we will build upon 
Simple voiceover to guide the demo (optionally, for clarity)
 - Create a draft of the icon of the app, and work with the non-profit clients to reinforce the icon design 
 - Get an account for the AWS service we need to use
