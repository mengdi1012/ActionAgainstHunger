# ActionAgainstHunger

#### Q1: What are you planning to build? 			

We are building an Android app for Action Against Hunger to help their programs launched in schools across Ontario. 

Our initial problem was straight forward from our clients. What would be an effective method to allow younger students in schools across Ontario to learn about health and nutrition? While inviting guest speakers and teaching them would be great, the retention was a problem across most students. So, in our era of technology, we hope to use the benefits of apps and mobility to increase student interest and retention.

The app is a forum-style discussion board for children to ask questions and share their progress on nutrition-based projects. It will also feature special guests such as nutrition specialists to provide advice and answer questions. After the app is complete, we are planning on creating a web counterpart for better accessibility. 

Action Against Hunger brings their program to 27 schools across Ontario every year, and they are hoping to increase that number in the near future. Our app can provide them with an effective medium for facilitating discussions between students from different schools. This helps create a sense of community and will allow them to learn together and grow. One common use case we discussed with the client was that when children are growing plants, it would be useful if they could regularly post pictures to track progress. Teachers and other students could chime in to give tips or compliments.



Here is a rough mockup of what the feed could look like:

<p align:"center"><br>
<img src="https://imgur.com/iyTtBES.png" style="float:left;"width="256" title="Reorder tasks"> <br><br>
</p>

#### Q2: Who are your target users?

Here are a few main groups of users we hope to target:

 - 5 to 18 year old students whose schools are enrolled in the Action Against Hunger program.
 - Administrators and educators like teachers and staff members.
 - Guest members like nutrition and health professionals, farmers and growing experts, and food justice leaders


#### Q3: Why would your users choose your product? What are they using today to solve their problem/need?   

Children and teenagers often do not know what is best for them and seldom search up nutrition facts unless they are in an environment where other people are concerned about what they eat. We plan to create a health conscious community where students have access to nutrition experts and teachers who can share expertise regarding healthy eating and farming. This will save time as students would have otherwise have to go and talk to these experts in person, which could take weeks depending on scheduling; our app however allows instant access. 

Our app also creates an environment in which students know that the information is trustworthy as the farming and nutrition leaders’ posts/comments would be made known to all viewers. This aura of trustworthiness is important as the food we eat and how we grow it affects our health, and students could have much more productive lives later on by eating healthy now.

Our solution is better as the other option for curious students is by using Google, which provides trustworthy and non trustworthy sources. These searches might not be easy to follow and suitable for students at their age. Students can also learn from other students’ discussions about their changes in nutrition, and the problems it helped solve. As our app follows a post and comment structure, this makes reading and understanding easier, where in the past they would have had to talk to multiple people to have the same exposure.


----

### Highlights


Decision on the web service platform:
    We were deciding between Firebase, AWS, and another smaller one
    Ultimately, AWS seemed to provide the most benefits at the free option, so after the clients were content, we finalized on it

How we would meet with the clients:
    We all grouped and finalized a time where the majority of us would be okay with meeting up with our clients
    Created a google docs and brainstormed a variety of questions to ask
    Also created docs to record key aspects of the clients’ answers
    Our clients were not tech savvy, or so to speak. So a lot of their thoughts and suggestions were quite nuanced from a code point of view. Thus, scribbling all important details and analyzing them later would be our best course of action.
    It also allowed us to collaboratively enter suggestions and information dump, so it was the most efficient method at that.

How we would tackle the general process of our project:
    Effectively, we weren’t sure how much work we should try to get done early on, how we would communicate with each other, how much planning we needed to do before coding, and so on.
    We decided to take a simple approach. We would all gather at specified times as much as possible, and all brainstorm what to do next. If any conflicts occured, we would work them out through feasibility analysis and otherwise majority opinion. 
    This worked well because it did not enforce a strict schedule onto any of us, and neither did it make the project seem super hard to manage.
    The result was that while we might still be able to do better on coordination and firmly giving out roles, we get a lot of work done - at least so far for the planning section. So, we think this type of working strategy is good enough to use until something drastic arises.


