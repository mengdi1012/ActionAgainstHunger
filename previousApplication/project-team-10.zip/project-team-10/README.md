# project-team-10

Here is a brief summary of what team 10 has achieved in the past semester: 

Technology: we are using android studio to create the mobile app, and amplify for authentication, AWS DynamoDB for data storation.

Front end: we finished the login and register, the structure of the forum(including viewing news, posts, comments, creating new posts, making comments...), features like filtering posts.

Back end: we achieved the user authentication, and users can be managed by AWS cognito.
    we also set up the connection to the dynamodb so that we can read/write posts and comments from the AWS DynamoDB.

Note:  Database connection can be viewed under this account of aws: 
    account ID: 680378715691
    user name: 301team-0, password:301actionagainsthunger.

    Our project service is located under the mobile hub of this account.

Some features to implement in future: 
    Improve the authentification, try to make it easier when users want to create a pool of users without email verification. One possible way is to use AWS cognito directly.
    Enable the image and videos/audios storation in dynamoDB. One way to do is to use AWS mobile hub and try User file storage.
    Enhance front end functionality and design.

