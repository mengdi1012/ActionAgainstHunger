package ca.actionagainsthunger.amazonaws.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "actionagainsthunger-mobilehub-1944626418-comments")

public class CommentsDO {
    private String _commentId;
    private String _content;
    private long _createdAt;
    private String _postId;
    private String _userId;
    private String _username;

    @DynamoDBHashKey(attributeName = "commentId")
    @DynamoDBAttribute(attributeName = "commentId")
    public String getCommentId() {
        return _commentId;
    }

    public void setCommentId(final String _commentId) {
        this._commentId = _commentId;
    }
    @DynamoDBAttribute(attributeName = "content")
    public String getContent() {
        return _content;
    }

    public void setContent(final String _content) {
        this._content = _content;
    }
    @DynamoDBAttribute(attributeName = "createdAt")
    public long getCreatedAt() {
        return _createdAt;
    }

    public void setCreatedAt(final long _createdAt) {
        this._createdAt = _createdAt;
    }
    @DynamoDBIndexHashKey(attributeName = "postId", globalSecondaryIndexName = "postId")
    public String getPostId() {
        return _postId;
    }

    public void setPostId(final String _postId) {
        this._postId = _postId;
    }
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBAttribute(attributeName = "username")
    public String getUsername() {
        return _username;
    }

    public void setUsername(final String _username) {
        this._username = _username;
    }

}
