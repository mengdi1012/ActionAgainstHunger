package ca.actionagainsthunger.user_files;

public enum UserType {
    ADMIN,STUDENT,TEACHER,GUEST
}
