package ca.actionagainsthunger.amazonaws.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "actionagainsthunger-mobilehub-1944626418-posts")

public class PostsDO {
    private String _postId;
    private Set<String> _comments;
    private String _content;
    private long _createdAt;
    private String _school;
    private String _title;
    private String _type;
    private String _userId;
    private String _username;

    @DynamoDBHashKey(attributeName = "postId")
    @DynamoDBAttribute(attributeName = "postId")
    public String getPostId() {
        return _postId;
    }

    public void setPostId(final String _postId) {
        this._postId = _postId;
    }
    @DynamoDBAttribute(attributeName = "comments")
    public Set<String> getComments() {
        return _comments;
    }

    public void setComments(final Set<String> _comments) {
        this._comments = _comments;
    }
    @DynamoDBAttribute(attributeName = "content")
    public String getContent() {
        return _content;
    }

    public void setContent(final String _content) {
        this._content = _content;
    }
    @DynamoDBIndexRangeKey(attributeName = "createdAt", globalSecondaryIndexNames = {"getUserPosts","getSchoolPosts",})
    public long getCreatedAt() {
        return _createdAt;
    }

    public void setCreatedAt(final long _createdAt) {
        this._createdAt = _createdAt;
    }
    @DynamoDBIndexHashKey(attributeName = "school", globalSecondaryIndexName = "getSchoolPosts")
    public String getSchool() {
        return _school;
    }

    public void setSchool(final String _school) {
        this._school = _school;
    }
    @DynamoDBAttribute(attributeName = "title")
    public String getTitle() {
        return _title;
    }

    public void setTitle(final String _title) {
        this._title = _title;
    }
    @DynamoDBAttribute(attributeName = "type")
    public String getType() {
        return _type;
    }

    public void setType(final String _type) {
        this._type = _type;
    }
    @DynamoDBIndexHashKey(attributeName = "userId", globalSecondaryIndexName = "getUserPosts")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBAttribute(attributeName = "username")
    public String getUsername() {
        return _username;
    }

    public void setUsername(final String _username) {
        this._username = _username;
    }

}
